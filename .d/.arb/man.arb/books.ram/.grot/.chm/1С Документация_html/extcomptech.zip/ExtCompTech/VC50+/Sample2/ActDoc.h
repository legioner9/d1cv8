// ActDoc.h : main header file for the ACTDOC application
//

#if !defined(AFX_ACTDOC_H__3542F5BA_EE74_11D2_8BF4_008048DA120F__INCLUDED_)
#define AFX_ACTDOC_H__3542F5BA_EE74_11D2_8BF4_008048DA120F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'precomp.h' before including this file for PCH
#endif

#include "ActRes.h"       // main symbols

#include "ActTlb.h"
#include "mci.h"


/////////////////////////////////////////////////////////////////////////////
// CActDocApp:
// See ActDoc.cpp for the implementation of this class
//

class CActDocApp : public CWinApp
{
public:
	CActDocApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CActDocApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	COleTemplateServer m_server;
		// Server object for document creation
	//{{AFX_MSG(CActDocApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

class CActDocDoc;

class CActDocSrvrItem : public CDocObjectServerItem
{
	DECLARE_DYNAMIC(CActDocSrvrItem)

// Constructors
public:
	CActDocSrvrItem(CActDocDoc* pContainerDoc);

// Attributes
	CActDocDoc* GetDocument() const
		{ return (CActDocDoc*)CDocObjectServerItem::GetDocument(); }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CActDocSrvrItem)
	public:
	virtual BOOL OnDraw(CDC* pDC, CSize& rSize);
	virtual BOOL OnGetExtent(DVASPECT dwDrawAspect, CSize& rSize);
	//}}AFX_VIRTUAL

// Implementation
public:
	~CActDocSrvrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
};

class CActDocDoc : public COleServerDoc
{

protected: // create from serialization only
	CActDocDoc();
	DECLARE_DYNCREATE(CActDocDoc)

public:
    Cmci mciCtrl;

	CActDocSrvrItem* GetEmbeddedItem()
		{ return (CActDocSrvrItem*)COleServerDoc::GetEmbeddedItem(); }

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CActDocDoc)
	protected:
	virtual COleServerItem* OnGetEmbeddedItem();
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CActDocDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	virtual CDocObjectServer* GetDocObjectServer(LPOLEDOCUMENTSITE pDocSite);

// Generated message map functions
protected:
	//{{AFX_MSG(CActDocDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CActDocDoc)
	afx_msg void SetFileName(LPCTSTR csFName);
	afx_msg void Play();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()


	DECLARE_INTERFACE_MAP()
};

class CActDocView : public CView
{
protected: // create from serialization only
	CActDocView();
	DECLARE_DYNCREATE(CActDocView)

// Attributes
    CWnd mciWindow;

public:
	CActDocDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CActDocView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CActDocView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CActDocView)
	afx_msg void OnCancelEditSrvr();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ActDocView.cpp
inline CActDocDoc* CActDocView::GetDocument()
   { return (CActDocDoc*)m_pDocument; }
#endif

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ACTDOC_H__3542F5BA_EE74_11D2_8BF4_008048DA120F__INCLUDED_)
