// ActDoc.cpp : Defines the class behaviors for the application.
//

#include "precomp.h"
#include <atlconv.h>
#include "ActDoc_i.c"
#include "ActDoc.h"
#include "MainFrm.h"
#include "IpFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CActDocApp

BEGIN_MESSAGE_MAP(CActDocApp, CWinApp)
	//{{AFX_MSG_MAP(CActDocApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CActDocApp construction

CActDocApp::CActDocApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CActDocApp object

CActDocApp theApp;

// This identifier was generated to be statistically unique for your app.
// You may change it if you prefer to choose a specific identifier.

// {3542F5B5-EE74-11D2-8BF4-008048DA120F}
static const CLSID clsid =
{ 0x3542f5b5, 0xee74, 0x11d2, { 0x8b, 0xf4, 0x0, 0x80, 0x48, 0xda, 0x12, 0xf } };

/////////////////////////////////////////////////////////////////////////////
// CActDocApp initialization

BOOL CActDocApp::InitInstance()
{
	// Initialize OLE libraries
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CActDocDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CActDocView));
	pDocTemplate->SetServerInfo(
		IDR_SRVR_EMBEDDED, IDR_SRVR_INPLACE,
		RUNTIME_CLASS(CInPlaceFrame));
	AddDocTemplate(pDocTemplate);

	// Connect the COleTemplateServer to the document template.
	//  The COleTemplateServer creates new documents on behalf
	//  of requesting OLE containers by using information
	//  specified in the document template.
	m_server.ConnectTemplate(clsid, pDocTemplate, TRUE);
		// Note: SDI applications register server objects only if /Embedding
		//   or /Automation is present on the command line.

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Check to see if launched as OLE server
	if (cmdInfo.m_bRunEmbedded || cmdInfo.m_bRunAutomated)
	{
		// Register all OLE server (factories) as running.  This enables the
		//  OLE libraries to create objects from other applications.
		COleTemplateServer::RegisterAll();

		// Application was run with /Embedding or /Automation.  Don't show the
		//  main window in this case.
		return TRUE;
	}

	// When a server application is launched stand-alone, it is a good idea
	//  to update the system registry in case it has been damaged.
	m_server.UpdateRegistry(OAT_DOC_OBJECT_SERVER);
	COleObjectFactory::UpdateRegistryAll();

	// When a mini-server is run stand-alone the registry is updated and the
	//  user is instructed to use the Insert Object dialog in a container
	//  to use the server.  Mini-servers do not have stand-alone user interfaces.
	AfxMessageBox(IDP_USE_INSERT_OBJECT);
	return FALSE;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CActDocApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CActDocApp message handlers

/////////////////////////////////////////////////////////////////////////////
// CActDocSrvrItem implementation

IMPLEMENT_DYNAMIC(CActDocSrvrItem, CDocObjectServerItem)

CActDocSrvrItem::CActDocSrvrItem(CActDocDoc* pContainerDoc)
	: CDocObjectServerItem(pContainerDoc, TRUE)
{
	// TODO: add one-time construction code here
	//  (eg, adding additional clipboard formats to the item's data source)
}

CActDocSrvrItem::~CActDocSrvrItem()
{
	// TODO: add cleanup code here
}

void CActDocSrvrItem::Serialize(CArchive& ar)
{
	// CActDocSrvrItem::Serialize will be called by the framework if
	//  the item is copied to the clipboard.  This can happen automatically
	//  through the OLE callback OnGetClipboardData.  A good default for
	//  the embedded item is simply to delegate to the document's Serialize
	//  function.  If you support links, then you will want to serialize
	//  just a portion of the document.

	if (!IsLinkedItem())
	{
		CActDocDoc* pDoc = GetDocument();
		ASSERT_VALID(pDoc);
		pDoc->Serialize(ar);
	}
}

BOOL CActDocSrvrItem::OnGetExtent(DVASPECT dwDrawAspect, CSize& rSize)
{
	// Most applications, like this one, only handle drawing the content
	//  aspect of the item.  If you wish to support other aspects, such
	//  as DVASPECT_THUMBNAIL (by overriding OnDrawEx), then this
	//  implementation of OnGetExtent should be modified to handle the
	//  additional aspect(s).

	if (dwDrawAspect != DVASPECT_CONTENT)
		return CDocObjectServerItem::OnGetExtent(dwDrawAspect, rSize);

	// CActDocSrvrItem::OnGetExtent is called to get the extent in
	//  HIMETRIC units of the entire item.  The default implementation
	//  here simply returns a hard-coded number of units.

	CActDocDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: replace this arbitrary size

	rSize = CSize(3000, 3000);   // 3000 x 3000 HIMETRIC units

	return TRUE;
}

BOOL CActDocSrvrItem::OnDraw(CDC* pDC, CSize& rSize)
{
	// Remove this if you use rSize
	UNREFERENCED_PARAMETER(rSize);

	CActDocDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: set mapping mode and extent
	//  (The extent is usually the same as the size returned from OnGetExtent)
	pDC->SetMapMode(MM_ANISOTROPIC);
	pDC->SetWindowOrg(0,0);
	pDC->SetWindowExt(3000, 3000);

	// TODO: add drawing code here.  Optionally, fill in the HIMETRIC extent.
	//  All drawing takes place in the metafile device context (pDC).

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CActDocSrvrItem diagnostics

#ifdef _DEBUG
void CActDocSrvrItem::AssertValid() const
{
	CDocObjectServerItem::AssertValid();
}

void CActDocSrvrItem::Dump(CDumpContext& dc) const
{
	CDocObjectServerItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////
// CActDocDoc

IMPLEMENT_DYNCREATE(CActDocDoc, COleServerDoc)

BEGIN_MESSAGE_MAP(CActDocDoc, COleServerDoc)
	//{{AFX_MSG_MAP(CActDocDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CActDocDoc, COleServerDoc)
	//{{AFX_DISPATCH_MAP(CActDocDoc)
	DISP_FUNCTION(CActDocDoc, "SetFileName", SetFileName, VT_EMPTY, VTS_BSTR)
	DISP_FUNCTION(CActDocDoc, "Play", Play, VT_EMPTY, VTS_NONE)
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IActDoc to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {3542F5B7-EE74-11D2-8BF4-008048DA120F}
static const IID IID_IActDoc =
{ 0x3542f5b7, 0xee74, 0x11d2, { 0x8b, 0xf4, 0x0, 0x80, 0x48, 0xda, 0x12, 0xf } };

BEGIN_INTERFACE_MAP(CActDocDoc, COleServerDoc)
	INTERFACE_PART(CActDocDoc, IID_IActDoc, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CActDocDoc construction/destruction

CActDocDoc::CActDocDoc()
{
	// Use OLE compound files
	EnableCompoundFile();

	// TODO: add one-time construction code here

	EnableAutomation();

	AfxOleLockApp();
}

CActDocDoc::~CActDocDoc()
{
	AfxOleUnlockApp();
}

BOOL CActDocDoc::OnNewDocument()
{
	if (!COleServerDoc::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CActDocDoc server implementation

COleServerItem* CActDocDoc::OnGetEmbeddedItem()
{
	// OnGetEmbeddedItem is called by the framework to get the COleServerItem
	//  that is associated with the document.  It is only called when necessary.

	CActDocSrvrItem* pItem = new CActDocSrvrItem(this);
	ASSERT_VALID(pItem);
	return pItem;
}

/////////////////////////////////////////////////////////////////////////////
// CActDocDoc Active Document server implementation

CDocObjectServer *CActDocDoc::GetDocObjectServer(LPOLEDOCUMENTSITE pDocSite)
{
	return new CDocObjectServer(this, pDocSite);
}

/////////////////////////////////////////////////////////////////////////////
// CActDocDoc serialization

void CActDocDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CActDocDoc diagnostics

#ifdef _DEBUG
void CActDocDoc::AssertValid() const
{
	COleServerDoc::AssertValid();
}

void CActDocDoc::Dump(CDumpContext& dc) const
{
	COleServerDoc::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CActDocDoc commands

void CActDocDoc::SetFileName(LPCTSTR csFName) 
{
    mciCtrl.SetFileName(csFName);
}

void CActDocDoc::Play() 
{
    mciCtrl.SetCommand("Open");
}

/////////////////////////////////////////////////////////////////////////////
// CActDocView

IMPLEMENT_DYNCREATE(CActDocView, CView)

BEGIN_MESSAGE_MAP(CActDocView, CView)
	//{{AFX_MSG_MAP(CActDocView)
	ON_COMMAND(ID_CANCEL_EDIT_SRVR, OnCancelEditSrvr)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CActDocView construction/destruction

CActDocView::CActDocView()
{
	// TODO: add construction code here

}

CActDocView::~CActDocView()
{
}

BOOL CActDocView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CActDocView drawing

void CActDocView::OnDraw(CDC* pDC)
{
	CActDocDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// OLE Server support

// The following command handler provides the standard keyboard
//  user interface to cancel an in-place editing session.  Here,
//  the server (not the container) causes the deactivation.
void CActDocView::OnCancelEditSrvr()
{
	GetDocument()->OnDeactivateUI(FALSE);
}

/////////////////////////////////////////////////////////////////////////////
// CActDocView diagnostics

#ifdef _DEBUG
void CActDocView::AssertValid() const
{
	CView::AssertValid();
}

void CActDocView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CActDocDoc* CActDocView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CActDocDoc)));
	return (CActDocDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CActDocView message handlers

void CActDocView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
    CActDocDoc *pDoc = GetDocument();
    Cmci *mciCtrl  = &pDoc->mciCtrl;
    CRect rct;
    GetClientRect(&rct);
    rct.bottom = 25;
    mciCtrl->Create("",WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_CHILD,rct,this,0);
    GetClientRect(&rct);
    rct.top = 25;
    mciWindow.Create(AfxRegisterWndClass(CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW),"",WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_CHILD,rct,this,0);

    mciCtrl->SetHWndDisplay((long) mciWindow.GetSafeHwnd()) ;
    mciCtrl->SetBorderStyle(0);
    mciCtrl->SetRecordVisible(FALSE);
    mciCtrl->SetEjectVisible(FALSE);
    mciCtrl->SetBackVisible(FALSE);
    mciCtrl->SetStepVisible(FALSE);

    mciCtrl->SetPlayEnabled(TRUE);
}

void CActDocView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
    CActDocDoc *pDoc = GetDocument();
    Cmci *mciCtrl  = &pDoc->mciCtrl;
    if (mciCtrl->GetSafeHwnd() == NULL) return;

    CRect rctView,rct;
    GetClientRect(&rctView);
    mciCtrl->GetWindowRect(&rct);
    mciCtrl->SetWindowPos(NULL,0,0,rctView.Width(),rct.Height(),SWP_NOMOVE | SWP_NOZORDER);
    mciWindow.GetWindowRect(&rct);
    mciWindow.SetWindowPos(NULL,0,0,rctView.Width(),rct.Height(),SWP_NOMOVE | SWP_NOZORDER);
}
