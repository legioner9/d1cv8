//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AddIn.rc
//
#define IDS_OBJECT_NAME                 100
#define IDR_AddIn                       103
#define IDS_PROPPAGE_CAPTION            103
#define IDS_MESSAGE_SOURCE              105
#define IDD_ADDIN_PROP_PAGE             203
#define IDS_TERM_PROP_FILENAME          1001
#define IDS_TERM_METH_SHOW              1002
#define IDS_TERM_METH_SELFROMFILE       1003
#define IDS_TERM_METH_SELFROMREF        1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        204
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
