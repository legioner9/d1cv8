// precomp.cpp : source file that includes just the standard includes
//	actdoc.pch will be the pre-compiled header
//	precomp.obj will contain the pre-compiled type information

#include "precomp.h"
