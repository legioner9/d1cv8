//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ActDoc.rc
//
#define IDR_SRVR_INPLACE                4
#define IDR_SRVR_EMBEDDED               5
#define IDD_ABOUTBOX                    100
#define ProgID                          100
#define IDP_USE_INSERT_OBJECT           101
#define IDP_OLE_INIT_FAILED             102
#define IDS_STRING103                   103
#define IDR_MAINFRAME                   128
#define IDR_ACTDOCTYPE                  129
#define IDS_TERM_PROP_FILENAME          1001
#define IDS_TERM_METH_SHOW              1002
#define IDS_TERM_METH_SELFROMFILE       1003
#define IDS_TERM_METH_SELFROMREF        1004
#define ID_CANCEL_EDIT_SRVR             32769

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
